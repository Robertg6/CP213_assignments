package cp213;

import java.util.Scanner;

public class Movie {
	public static void main(String[] args) {
		Movie obj1 = new Movie();
		Movie obj2 = new Movie("Dellamorte Dellamore", 1994, "Michele Soav", 7.2, 3);
		Movie obj3 = new Movie("Zulu", 2013, "Jérôme Sal", 6.7, 2);
		String result1 = obj1.toString();
		String result2 = obj2.toString();
		String result3 = obj3.toString();
		System.out.print(result1);
		System.out.print(result2);
		System.out.print(result3);
		int comp1 = obj1.compareTo(obj1);
		System.out.println(comp1);
		int comp2 = obj3.compareTo(obj1);
		System.out.println(comp2);
		int comp3 = obj1.compareTo(obj2);
		System.out.println(comp3);

	}

	private final int FIRST_YEAR = 1800;
	private final String[] GENRES = new String[] { "science fiction", "fantasy", "drama", "romance", "comedy", "zombie",
			"action", "historical", "horror", "war" };
	private final double MAX_RATING = 10.0;
	private final double MIN_RATING = 0.0;
	private String title;
	private String director;
	private int year;
	private int genre;
	private double rating;

	public int getFIRST_YEAR() {
		return (FIRST_YEAR);
	};

	public String[] getGENRES() {
		return (GENRES);
	};

	public double getMAX_RATING() {
		return (MAX_RATING);
	};

	public double getMIN_RATING() {
		return (MAX_RATING);
	};

	public String getTitle() {
		return (title);
	};

	public String getDirector() {
		return (director);
	};

	public int getYear() {
		return (year);
	}

	public int getGenre() {
		return (genre);
	};

	public double getRating() {
		return (rating);
	};

	public String setTitle(final String new_title) {
		title = new_title;
		return (title);
	}

	public String setDirector(final String arg) {
		director = arg;
		return (director);
	}

	public int setYear(final int arg) {
		year = arg;
		return (year);
	}

	public int setGenre(final int arg) {
		genre = arg;
		return (genre);
	}

	public double setRating(final double arg) {
		rating = arg;
		return (rating);
	}

	public String genreToName(int genreint) {
		String returngenre = GENRES[genreint];
		return (returngenre);
	}

	public final String genreMenu() {
		return ("0: Science Fiction\n" + "1: Fantasy\n" + "2: Drama\n" + "3: Romance\n" + "4: Comedy\n" + "5: Zombie\n"
				+ "6: Action\n" + "7: Historical\n" + "8: Horror\n" + "9: War\n");
	}

	public String toString() {
		String result = "";
		String genre = genreToName(getGenre());
		result += "Title: " + getTitle() + "\n";
		result += "Year: " + Integer.toString(getYear()) + "\n";
		result += "Director: " + getDirector() + "\n";
		result += "Rating: " + Double.toString(getRating()) + "\n";
		result += "Genre: " + genre + "\n";
		return (result);
	}

	public int compareTo(Movie self1) {
		int value_to_return = 0;
		boolean same_title = true;
		boolean same_year = true;
		boolean same_director = true;
		boolean same_rating = true;
		boolean same_genre = true;

		if (getTitle() != self1.getTitle()) {
			same_title = false;
		}
		if (getYear() != self1.getYear()) {
			same_year = false;
		}
		if (getDirector() != self1.getDirector()) {
			same_director = false;
		}
		if (getRating() != self1.getRating()) {
			same_rating = false;
		}
		if (getGenre() != self1.getGenre()) {
			same_genre = false;
		}

		if (same_title == false || same_genre == false || same_director == false || same_rating == false) {
			value_to_return = FIRST_YEAR;
		}
		if (same_year == false) {
			value_to_return = getYear() - self1.getYear();
		}
		return (value_to_return);
	}

	public Movie() {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Title: ");
		String title = keyboard.nextLine();
		setTitle(title);
		int num_year = 0;
		while (num_year < FIRST_YEAR) {
			System.out.print("year: ");
			String year = keyboard.nextLine();
			num_year = Integer.parseInt(year);
			if (num_year > FIRST_YEAR) {
				setYear(num_year);
			} 
			}
			
		
		System.out.print("Director: ");
		String director = keyboard.nextLine();
		setDirector(director);
		double num_rating = 11;
		while (num_rating >= MAX_RATING || num_rating <= MIN_RATING) {
			System.out.print("Rating: ");
			num_rating = keyboard.nextDouble();
			setRating(num_rating);
		}
	
	keyboard.nextLine();
	String genremenu = genreMenu();
	int num_genre = 10;
	while(num_genre>9 || num_genre<0){
		System.out.println(genremenu);
		System.out.println("Genre: ");
		String genre = keyboard.nextLine();
		num_genre = Integer.parseInt(genre);
	}

	keyboard.close();
	}

	public Movie(String arg1, int arg2, String arg3, double arg4, int arg5) {
		setTitle(arg1);
		setYear(arg2);
		setDirector(arg3);
		setRating(arg4);
		setGenre(arg5);
	}
}
