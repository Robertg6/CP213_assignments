package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.util.Random;
import javax.swing.JOptionPane;

public class A06Listeners {
	public A06Threads one_thread;
	public A06Threads two_thread;
	public A06Threads three_thread;
	public A06Threads four_thread;
	public A06Threads five_thread;
	public boolean is_shown = true;
	
	public void add_listeners(JButton current, ThreadsView pane, ButtonView button) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(pane.num_current_thread < 5) {
				Random r = new Random();
				int runtime = r.nextInt((2000-1000)+1)+1000;
				int sleeptime = r.nextInt((2000-1000)+1)+1000;
				pane.num_current_thread += 1;
				button.num_threads.setText("Current threads: " + pane.num_current_thread);
				if(pane.num_current_thread == 1){
					A06Threads one_thread = new A06Threads(1,runtime,sleeptime,pane);
					one_thread.del_listeners(button.kill, pane, button, is_shown);
					pane.thread_1.setText("Thread 1:");
					pane.thread_1.setOpaque(true);
					pane.thread_1_status.setText("Status: Running");
					pane.thread_1_status.setOpaque(true);
					String str1 = Integer.toString(runtime);
					pane.thread_1_run.setText("Run: "+ str1);
					pane.thread_1_run.setOpaque(true);
					String str2 = Integer.toString(sleeptime);
					pane.thread_1_sleep.setText("Sleep: " + str2);
					pane.thread_1_sleep.setOpaque(true);
				}
				else if(pane.num_current_thread == 2){
					A06Threads two_thread = new A06Threads(2,runtime,sleeptime,pane);
					two_thread.del_listeners(button.kill, pane, button, is_shown);
					pane.thread_2.setText("Thread 1:");
					pane.thread_2.setOpaque(true);
					pane.thread_2_status.setText("Status: Running");
					pane.thread_2_status.setOpaque(true);
					String str1 = Integer.toString(runtime);
					pane.thread_2_run.setText("Run: "+ str1);
					pane.thread_2_run.setOpaque(true);
					String str2 = Integer.toString(sleeptime);
					pane.thread_2_sleep.setText("Sleep: " + str2);
					pane.thread_2_sleep.setOpaque(true);
				
				}
				
				else if(pane.num_current_thread == 3){
					A06Threads three_thread = new A06Threads(3,runtime,sleeptime,pane);
					three_thread.del_listeners(button.kill, pane, button, is_shown);
					pane.thread_3.setText("Thread 1:");
					pane.thread_3.setOpaque(true);
					pane.thread_3_status.setText("Status: Running");
					pane.thread_3_status.setOpaque(true);
					String str1 = Integer.toString(runtime);
					pane.thread_3_run.setText("Run: "+ str1);
					pane.thread_3_run.setOpaque(true);
					String str2 = Integer.toString(sleeptime);
					pane.thread_3_sleep.setText("Sleep: " + str2);
					pane.thread_3_sleep.setOpaque(true);
				}
				
				else if(pane.num_current_thread == 4){
					A06Threads four_thread = new A06Threads(4,runtime,sleeptime,pane);
					four_thread.del_listeners(button.kill, pane, button ,is_shown);
					pane.thread_4.setText("Thread 1:");
					pane.thread_4.setOpaque(true);
					pane.thread_4_status.setText("Status: Running");
					pane.thread_4_status.setOpaque(true);
					String str1 = Integer.toString(runtime);
					pane.thread_4_run.setText("Run: "+ str1);
					pane.thread_4_run.setOpaque(true);
					String str2 = Integer.toString(sleeptime);
					pane.thread_4_sleep.setText("Sleep: " + str2);
					pane.thread_4_sleep.setOpaque(true);
				
				}
				else if(pane.num_current_thread == 5){
					A06Threads five_thread = new A06Threads(5,runtime,sleeptime,pane);
					five_thread.del_listeners(button.kill, pane, button, is_shown);
					pane.thread_5.setText("Thread 1:");
					pane.thread_5.setOpaque(true);
					pane.thread_5_status.setText("Status: Running");
					pane.thread_5_status.setOpaque(true);
					String str1 = Integer.toString(runtime);
					pane.thread_5_run.setText("Run: "+ str1);
					pane.thread_5_run.setOpaque(true);
					String str2 = Integer.toString(sleeptime);
					pane.thread_5_sleep.setText("Sleep: " + str2);
					pane.thread_5_sleep.setOpaque(true);
				
				}
			}
				else{
					JOptionPane.showMessageDialog(null, "Cannot add more then 5!");}}
		});}
	public void popuplistener(JButton current, ThreadsView pane, ButtonView button) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			
				if(pane.num_current_thread == 0) {
									JOptionPane.showMessageDialog(null, "Cannot delete when there arent any");
									}
				}
			
	});}
	
	

	
	
		
	}
	
	
