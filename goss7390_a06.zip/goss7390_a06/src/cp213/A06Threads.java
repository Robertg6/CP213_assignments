package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.util.Random;

import java.util.Random;
import java.awt.color.*;
import cp213.A06.*;
import javax.swing.JOptionPane;

import javax.swing.Timer;


	class A06Threads extends Thread 
	{	
		public int id = 0;
		public boolean active = true;
		public  int awake = 0;
		public int asleep  = 0;
		public ThreadsView pane = new ThreadsView();
		A06Listeners listener = new A06Listeners();
		public void run() 
		{ 
		while(this.active == true) {
			System.out.println("Thread " + this.id + " is running");
			change_colour_green();
			try {
				Thread.sleep(awake);
			} catch(InterruptedException ex) {
			System.out.println("I was interrupted");
			}
			change_colour_red();
			try {
				Thread.sleep(asleep);
			} catch (InterruptedException ex) {
				System.out.println("I was interrupted");
			}
		
		}} 
		public A06Threads(int id, int awake, int asleep, ThreadsView pane) {
		
			this.pane = pane;
			this.id = id;
			this.active = true;
			this.awake = awake;
			this.asleep = asleep;
			System.out.println("Thread " + this.id + " started running.....");
			this.start();
			
			
		
		
		
		}
	
		
		
		public void change_colour_red() {
			
			if(this.id == 1) {
				this.pane.thread_1.setBackground(Color.RED);
				this.pane.thread_1_run.setBackground(Color.RED);
				this.pane.thread_1_status.setBackground(Color.RED);
				this.pane.thread_1_sleep.setBackground(Color.RED);
				if(this.active == true) {
				this.pane.thread_1_status.setText("Status: Sleeping");
			}}
			if(this.id == 2) {
				this.pane.thread_2.setBackground(Color.RED);
				this.pane.thread_2_run.setBackground(Color.RED);
				this.pane.thread_2_status.setBackground(Color.RED);
				this.pane.thread_2_sleep.setBackground(Color.RED);
				if(this.active == true) {
					this.pane.thread_2_status.setText("Status: Sleeping");
				}
			}
			if(this.id == 3) {
				this.pane.thread_3.setBackground(Color.RED);
				this.pane.thread_3_run.setBackground(Color.RED);
				this.pane.thread_3_status.setBackground(Color.RED);
				this.pane.thread_3_sleep.setBackground(Color.RED);
				if(this.active == true) {
					this.pane.thread_3_status.setText("Status: Sleeping");
				}
			}
			if(this.id == 4) {
				this.pane.thread_4.setBackground(Color.RED);
				this.pane.thread_4_run.setBackground(Color.RED);
				this.pane.thread_4_status.setBackground(Color.RED);
				this.pane.thread_4_sleep.setBackground(Color.RED);
				if(this.active == true) {
					this.pane.thread_4_status.setText("Status: Sleeping");
				}
			}
			if(this.id == 5) {
				this.pane.thread_5.setBackground(Color.RED);
				this.pane.thread_5_run.setBackground(Color.RED);
				this.pane.thread_5_status.setBackground(Color.RED);
				this.pane.thread_5_sleep.setBackground(Color.RED);
				if(this.active == true) {
					this.pane.thread_5_status.setText("Status: Sleeping");
				}
			}	
		}
		public void change_colour_green() {
			if(this.id == 1) {
				this.pane.thread_1.setBackground(Color.GREEN);
				this.pane.thread_1_run.setBackground(Color.GREEN);
				this.pane.thread_1_status.setBackground(Color.GREEN);
				this.pane.thread_1_sleep.setBackground(Color.GREEN);
				this.pane.thread_1_status.setText("Status: Running");
			}
			if(this.id == 2) {
				this.pane.thread_2.setBackground(Color.GREEN);
				this.pane.thread_2_run.setBackground(Color.GREEN);
				this.pane.thread_2_status.setBackground(Color.GREEN);
				this.pane.thread_2_sleep.setBackground(Color.GREEN);
				this.pane.thread_2_status.setText("Status: Running");
			}
			if(this.id == 3) {
				this.pane.thread_3.setBackground(Color.GREEN);
				this.pane.thread_3_run.setBackground(Color.GREEN);
				this.pane.thread_3_status.setBackground(Color.GREEN);
				this.pane.thread_3_sleep.setBackground(Color.GREEN);
				this.pane.thread_3_status.setText("Status: Running");
			}
			if(this.id == 4) {
				this.pane.thread_4.setBackground(Color.GREEN);
				this.pane.thread_4_run.setBackground(Color.GREEN);
				this.pane.thread_4_status.setBackground(Color.GREEN);
				this.pane.thread_4_sleep.setBackground(Color.GREEN);
				this.pane.thread_4_status.setText("Status: Running");
			}
			if(this.id == 5) {
				this.pane.thread_5.setBackground(Color.GREEN);
				this.pane.thread_5_run.setBackground(Color.GREEN);
				this.pane.thread_5_status.setBackground(Color.GREEN);
				this.pane.thread_5_sleep.setBackground(Color.GREEN);
				this.pane.thread_5_status.setText("Status: Running");
			}
			
		}
		public void del_listeners(JButton current, ThreadsView pane, ButtonView button, boolean is_shown) {
			current.addActionListener(new ActionListener() {
				@Override
				
				public void actionPerformed(ActionEvent e) {
					
					
					if((pane.num_current_thread > 0)) {
					pane.num_current_thread -= 1;
					button.num_threads.setText("Current threads: " + pane.num_current_thread);
					active = false;
					pane.thread_1.setText(" ");
					pane.thread_1.setOpaque(false);
					pane.thread_1_sleep.setText(" ");
					pane.thread_1_sleep.setOpaque(false);
					pane.thread_1_run.setText(" ");
					pane.thread_1_run.setOpaque(false);
					pane.thread_1_status.setText(" ");
					pane.thread_1_status.setOpaque(false);
					pane.thread_2.setText(" ");
					pane.thread_2.setOpaque(false);
					pane.thread_2_sleep.setText(" ");
					pane.thread_2_sleep.setOpaque(false);
					pane.thread_2_run.setText(" ");
					pane.thread_2_run.setOpaque(false);
					pane.thread_2_status.setText(" ");
					pane.thread_2_status.setOpaque(false);
					pane.thread_3.setText(" ");
					pane.thread_3.setOpaque(false);
					pane.thread_3_sleep.setText(" ");
					pane.thread_3_sleep.setOpaque(false);
					pane.thread_3_run.setText(" ");
					pane.thread_3_run.setOpaque(false);
					pane.thread_3_status.setText(" ");
					pane.thread_3_status.setOpaque(false);
					pane.thread_4.setText(" ");
					pane.thread_4.setOpaque(false);
					pane.thread_4_sleep.setText(" ");
					pane.thread_4_sleep.setOpaque(false);
					pane.thread_4_run.setText(" ");
					pane.thread_4_run.setOpaque(false);
					pane.thread_4_status.setText(" ");
					pane.thread_4_status.setOpaque(false);
					pane.thread_5.setText(" ");
					pane.thread_5.setOpaque(false);
					pane.thread_5_sleep.setText(" ");
					pane.thread_5_sleep.setOpaque(false);
					pane.thread_5_run.setText(" ");
					pane.thread_5_run.setOpaque(false);
					pane.thread_5_status.setText(" ");
					pane.thread_5_status.setOpaque(false);
					}}
					
				
			});}
	}
		

	