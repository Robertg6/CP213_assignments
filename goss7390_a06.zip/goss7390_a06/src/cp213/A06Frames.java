package cp213;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class A06Frames extends JPanel {
	public ButtonView bv = new ButtonView();
	public ThreadsView tv = new ThreadsView();
	public A06Listeners listener = new A06Listeners();
	
	
	public A06Frames() {
		this.add(bv);
		this.add(tv);
		this.layoutView();
		listener.add_listeners(bv.add_thread, tv, bv);
		listener.popuplistener(bv.kill, tv, bv);
		
	}
	
	private void layoutView() {
		// Place the numeric and button views on top and the graphic view
		// underneath.
		
		this.setLayout(new BorderLayout());
		this.add(this.tv, BorderLayout.EAST);
		this.add(this.bv, BorderLayout.WEST);
		this.setVisible(true);
		
	
		
		
	

}	
	
	
}
