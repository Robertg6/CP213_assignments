package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;


public class ThreadsView extends JPanel {
	public int num_current_thread = 0;
	public JLabel thread_1 = new JLabel(" ");
	public JLabel thread_2 = new JLabel(" ");
	public JLabel thread_3 = new JLabel(" ");
	public JLabel thread_4 = new JLabel(" ");
	public JLabel thread_5 = new JLabel(" ");
	public JLabel thread_1_status = new JLabel(" ");
	public JLabel thread_2_status = new JLabel(" ");
	public JLabel thread_3_status = new JLabel(" ");
	public JLabel thread_4_status = new JLabel(" ");
	public JLabel thread_5_status = new JLabel(" ");
	public JLabel thread_1_run = new JLabel(" ");
	public JLabel thread_2_run = new JLabel(" ");
	public JLabel thread_3_run = new JLabel(" ");
	public JLabel thread_4_run = new JLabel(" ");
	public JLabel thread_5_run = new JLabel(" ");
	public JLabel thread_1_sleep = new JLabel(" ");
	public JLabel thread_2_sleep = new JLabel(" ");
	public JLabel thread_3_sleep = new JLabel(" ");
	public JLabel thread_4_sleep = new JLabel(" ");
	public JLabel thread_5_sleep = new JLabel(" ");
	A06Listeners listener = new A06Listeners();
	public ThreadsView() {
		
		this.setLayout(new GridLayout(4,6,100,0));
		this.add(thread_1);
		thread_1.setOpaque(true);
		this.add(thread_2);
		thread_2.setOpaque(true);
		this.add(thread_3);
		thread_3.setOpaque(true);
		this.add(thread_4);
		thread_4.setOpaque(true);
		this.add(thread_5);
		thread_5.setOpaque(true);
		this.add(thread_1_status);
		thread_1_status.setOpaque(true);
		this.add(thread_2_status);
		thread_2_status.setOpaque(true);
		this.add(thread_3_status);
		thread_3_status.setOpaque(true);
		this.add(thread_4_status);
		thread_4_status.setOpaque(true);
		this.add(thread_5_status);
		thread_5_status.setOpaque(true);
		this.add(thread_1_run);
		thread_1_run.setOpaque(true);
		this.add(thread_2_run);
		thread_2_run.setOpaque(true);
		this.add(thread_3_run);
		thread_3_run.setOpaque(true);
		this.add(thread_4_run);
		thread_4_run.setOpaque(true);
		this.add(thread_5_run);
		thread_5_run.setOpaque(true);
		this.add(thread_1_sleep);
		thread_1_sleep.setOpaque(true);
		this.add(thread_2_sleep);
		thread_2_sleep.setOpaque(true);
		this.add(thread_3_sleep);
		thread_3_sleep.setOpaque(true);
		this.add(thread_4_sleep);
		thread_4_sleep.setOpaque(true);
		this.add(thread_5_sleep);
		thread_5_sleep.setOpaque(true);
		
	}
	
	
		
			
	}
	

