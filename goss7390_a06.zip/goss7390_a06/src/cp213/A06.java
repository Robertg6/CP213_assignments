package cp213;

import javax.swing.JFrame;

public class A06 extends JFrame{
	public static void main(String[] args) {

		JFrame thread = new JFrame("Thread-o-matic");
		A06Frames fr = new A06Frames();
		thread.add(fr);
		thread.setVisible(true);
		
}}
