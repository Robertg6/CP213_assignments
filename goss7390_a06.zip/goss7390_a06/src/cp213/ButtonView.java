package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class ButtonView extends JPanel {
	public JButton add_thread = new JButton("Add a thread");
	public JButton kill = new JButton("Delete a thread");
	public JLabel num_threads = new JLabel("Number of threads: 0");
	
	public ButtonView() {
		this.setLayout(new GridLayout(3,1));
		this.add(num_threads);
		this.add(add_thread);
		this.add_thread.setBackground(Color.CYAN);
		this.add(kill);
		this.kill.setBackground(Color.CYAN);
		
	}
	
	
	
	
}
