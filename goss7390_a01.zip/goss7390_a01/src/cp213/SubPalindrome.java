package cp213;

import java.util.Arrays;
import java.util.Scanner;
import java.util.List;
import java.util.*;

public class SubPalindrome {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		boolean output = false;
		System.out.print("Enter a string of size 1 - 10: ");
		String text = keyboard.nextLine();
		int textsize = text.length();
		if (textsize == 0 || textsize < 10) {
			int minLen = textsize / 2;
			output = isPalindrome(text);
			testSubPalindromes(text, minLen);
		}
		;
		if (textsize == 0) {
			System.out.println("Is not a valid input, size less then 1");
		}
		;

		if (textsize > 10) {
			System.out.println(text + " " + "Is not a valid input, size more than 10");
		}
		;
		if (output == true) {
			System.out.println("yes");
		}
		;
		keyboard.close();
	}

	public static void testSubPalindromes(final String s, int minLen) {
		LinkedList<String> palindromes = new LinkedList<String>();

		for (int width = minLen; width <= s.length(); width++) {
			for (int start = 0; start < s.length() - width + 1; start++) {
				String sub = "";
				for (int i = start; i < start + width; i++) {
					sub += s.charAt(i);
				}
				String spaceless = sub.replaceAll("\\s", "");
				boolean is_palindrome = isPalindrome(spaceless);

				if ((is_palindrome == true) && (palindromes.contains(sub) == false)) {
					if ((sub.contains(" ") == false) || (sub.length() != 2)) {
						palindromes.add(sub);
					}
				}
			}
		}
		if (palindromes.size() == 0) {
			System.out.printf("No substrings of the string '%s' are palindromes.\n", s);
		} else {
			System.out.printf("The following substring(s) of the string '%s' are palindrome(s):  ", s);
			for (int a = 0; a < palindromes.size(); a++) {
				System.out.printf("'%s'", palindromes.get(a));
				if (a < palindromes.size() - 1) {
					System.out.print(", ");
				}
			}
		}

	}

	public static boolean isPalindrome(final String s) {
		boolean palindrome = true;
		for (int i = 0; (i < s.length()) && (palindrome == true); i++) {
			if (s.charAt(i) != s.charAt((s.length() - 1) - i)) {
				palindrome = false;
			}
		}
		return (palindrome);

	}
}
