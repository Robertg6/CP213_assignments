package cp213;

import java.util.*;

public class ValidDeclaration {
	public static void main(String args[]) {
		String out = "";
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter a thingy: ");
		String message = keyboard.nextLine();
		boolean indicator = isValid(message);
		System.out.println(indicator);
		keyboard.close();
		if (indicator == true) {
			out = message + "is a valid Java variable definition.";
			System.out.println(out);
		}
		if (indicator == false) {
			out = message + " is not a valid Java variable definition.";
			System.out.println(out);
		}
	}

	public static boolean isValid(final String statement) {
		boolean boo = true;
		List<String> items = Arrays.asList("byte", "int", "short", "char", "long", "double", "boolean");
		int i = 0;
		int section = 1;
		String section1 = "";
		String section2 = "";
		String section3 = "";
		while (boo == true && i < statement.length() && section == 1) {
			if (statement.charAt(i) == ' ') {
				section = 2;
			}
			if (statement.charAt(i) != ' ') {
				section1 += statement.charAt(i);
			}

			i += 1;

		}
		while (boo == true && i < statement.length() && section == 2) {
			if (statement.charAt(i) == ' ') {
				section = 3;
			}
			if (statement.charAt(i) != ' ' && statement.charAt(i) != ';') {
				section2 += statement.charAt(i);
			}
			if (statement.charAt(i) == ';') {
				section = 3;
				section3 = ";";
			}

			i += 1;
		}

		if (section3 != ";") {
			boo = false;
		}

		if (items.contains(section1) == false) {
			boo = false;
			System.out.println(boo);
		}

		if ((Character.isLetter(section2.charAt(0)) == true || (section2.charAt(0) == '_'))) {
			if (section2.charAt(0) == '_') {
				if (section2.length() == 1) {
					boo = false;
				}
			}
			for (int j = 1; (boo == true) && (j < section2.length()); j++) {
				if ((Character.isLetter(section2.charAt(j)) == false)
						&& (Character.isDigit(section2.charAt(j)) == false) && (section2.charAt(j) != '_')) {
					boo = false;
				}
			}

		}

		System.out.printf("'%s'\n", section1);
		System.out.printf("'%s'\n", section2);
		System.out.printf("'%s'\n", section3);
		return (boo);
	}

}
