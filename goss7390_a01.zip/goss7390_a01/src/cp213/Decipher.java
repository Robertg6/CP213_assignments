package cp213;

import java.util.Scanner;

public class Decipher {
	public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final int ALPHA_LENGTH = ALPHA.length();

	public static void main(String[] args) {
		final String CIPHERTEXT = "AVIBROWNZCEFGHJKLMPQSTUXYD";
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter a cipher string: ");
		String text = keyboard.nextLine();
		System.out.println("Enter a cipher shift:");
		int shif = keyboard.nextInt();
		String s = shift(text.toUpperCase(), shif);
		System.out.println(s);
		String s_2 = substitute(text.toUpperCase(), CIPHERTEXT);
		System.out.println(s_2);
	}

	/**
	 * Decipher a string using a shift cipher.
	 *
	 * @param s string to decipher
	 * @param n the number of letters to shift
	 * @return the original plaintext string
	 */
	public static String shift(String s, int n) {
		String new_s = "";
		int position = 0;
		for (int i = 0; i < s.length(); i++) {
			boolean boo = false;
			for (int j = 0; j < ALPHA.length() || boo == false; j++) {
				if (ALPHA.charAt(j) == s.charAt(i)) {
					boo = true;
					position = j;
				}

			}
			if (position - n > 0) {
				new_s += ALPHA.charAt((position - n) % 26);
			}
			if (position - n < 0) {
				new_s += ALPHA.charAt(((position - n) % 26) + 26);
			}
		}
		return (new_s);
	}

	/**
	 * Decipher a string using the letter positions in ciphertext.
	 *
	 * @param s          string to decipher
	 * @param ciphertext ciphertext alphabet
	 * @return the plaintext string
	 */
	public static String substitute(String s, String ciphertext) {
		String s_2 = "";
		int position = 0;
		for (int i = 0; i < s.length(); i++) {
			boolean boo = false;
			for (int j = 0; j < ALPHA.length() || boo == false; j++) {
				if (ciphertext.charAt(j) == s.charAt(i)) {
					boo = true;
					position = j;
				}
			}
			s_2 += ALPHA.charAt(position);
		}
		return (s_2);
	}
}