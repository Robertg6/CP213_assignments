package cp213;

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Process text files with three kinds of trees to determine their relative
 * efficiency.
 *
 * @author your name here
 * @version 2018-07-05
 */
public class A04 {

	/**
	 * Program for Assignment 4.
	 *
	 * @param args unused
	 * @throws IOException If error on files.
	 */
	public static void main(final String[] args) throws IOException {
	
		BST<Character> new_bst = new BST<Character>();
	
		PopularityTree<Character> new_pop = new PopularityTree<Character>();
		
		File training = new File("src/cp213/decline.txt");
		
		File comparisons = new File("src/cp213/miserables.txt");
		
		System.out.println("Training file: decline.txt");
		
		System.out.println("Comparisons file: miserables.txt");
		
		characterTable(new_bst);
		
		System.out.println("Tree type: BST");
		
		System.out.println("Training...");
		
		train(new_bst, training);
		
		System.out.println("Valid: " + new_bst.isValid());
		
		System.out.println("Height: " + new_bst.getHeight());
		
		System.out.println("Retrieveing...");
		
		System.out.println("Comparisons: " + retrieve(new_bst, training));
		
		System.out.println("--------------------------");

		System.out.println("Tree type: PopularityTree");
		
		System.out.println("Training...");
		
		train(new_pop, training);
		
		System.out.println("Valid: " + new_pop.isValid());
		
		System.out.println("Height: " + new_pop.getHeight());
		
		System.out.println("Retrieveing...");
		
		System.out.println("Comparisons: " + retrieve(new_pop, comparisons));
		
		System.out.println("--------------------------");

		
		if (new_pop.getComparisons() > new_bst.getComparisons()) {
			System.out.println("Tree with minumum comparison: BST");
		} else {
			System.out.println("Tree with minimum compariosn: PopularityTree");
		}

	}

	/**
	 * Determine the number of comparisons to retrieve the contents of a file from a
	 * tree. Reset the number of comparisons, then attempt to retrieve every letter
	 * in the file from tree. All letters must be converted to upper case.
	 *
	 * @param tree The BST to process.
	 * @param file The file to process.
	 * @return The number of comparisons necessary to find every letter in file in
	 *         tree.
	 * @throws FileNotFoundException Thrown if file not found.
	 */
	public static int retrieve(final BST<Character> tree,  final File file) throws FileNotFoundException {
		
		tree.resetComparisons();
		
		Scanner sc = new Scanner(file);
		
		String next_word = null;
		
		while (sc.hasNext()) {
			next_word = sc.next();
			next_word.toUpperCase();
			for (int i = 0; i < next_word.length(); i++) {
				if ((Character.isLetter(next_word.charAt(i)) == true)) {
					tree.retrieve(next_word.charAt(i));
				}
			}
		}
		sc.close();

		return tree.getComparisons();
	}

	/**
     * Train a tree by inserting all letters from a file into the tree. Letters
     * must be converted to upper-case. Non-letters are ignored.
     *
     * @param tree
     *            The BST to train.
     * @param file
     *            The file to read into the tree.
     * @throws FileNotFoundException
     *             Thrown if file not found.
     */
    public static void train( final BST<Character> tree,  final File file)
	    throws FileNotFoundException {
    	if (file == null) {
    		throw new FileNotFoundException();
    	}
    	Scanner sc = new Scanner(file);
    	String next_word = null;
    	
    	while (sc.hasNext()) {
    		next_word = sc.next();
    		next_word.toUpperCase();
    		for(int i = 0; i < next_word.length(); i++) {
        		if ((Character.isLetter(next_word.charAt(i))==true)) {
        			tree.insert(next_word.charAt(i));}}
    	} sc.close();
	return;}
    

	public static void characterTable(final BST<Character> tree) {
		
		System.out.println("----------------------------");
		
		System.out.println("Character Table for Training file\n");
		
		System.out.printf("%-8s%-7s%-8s\n", "Char","Count","Percent");
		
		File training = new File("src/cp213/decline.txt");
		
		final char[] letters = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		int[] letter_count = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		
		double[] percents = {0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00};
		try {
			Scanner sc = new Scanner(training);
			String next_word = null;
			
			while (sc.hasNext()) {
				next_word = sc.next();
				next_word.toUpperCase();
				
				for (int i = 0; i<next_word.length();i++) {
						for(int j = 0; j < letters.length; j++) {
							if(letters[j] == next_word.charAt(i)) {
								letter_count[j]+=1;
							
						}
					}
				}
			}
			
		sc.close();
		int total_count = 0;
		for ( int i=0; i<letters.length; i++){
			total_count += letter_count[i];
		}
		for(int i = 0; i<letters.length; i++) {
			percents[i] = (((double)letter_count[i]/(double)total_count)*(double)100);
		}
		
		for(int i=0; i<letters.length;i++) {
			System.out.printf("%-4c%-8d%-7.2f\n", letters[i],letter_count[i], percents[i] );
		}		
		}
		catch(FileNotFoundException e) {
			System.out.println("File not found!");}
		}
		
}	
