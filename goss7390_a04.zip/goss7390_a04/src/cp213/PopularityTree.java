package cp213;

/**
 * Implements a Popularity Tree. Extends BST.
 *
 * @author your name here
 * @version 2018-07-05
 *
 * @param <T> The data to store in the tree.
 */
public class PopularityTree<T extends Comparable<T>> extends BST<T> {
	
	public TreeNode<T> pt_retrieveParent(final T key) {
		
		TreeNode<T> current = root;
		
		TreeNode<T> prev = null;
		
		TreeNode<T> result = null;
		// Base Cases: root is null or key is present at root
		if (root == null || root.getData() == key) {
			result = null;
		}

		else {
			current.updateHeight();
			while (result == null) {
				prev = current;
				// val is greater than current's key
				if (key.compareTo(current.getData()) < 0) {
					current = current.getLeft();
				}

				// val is less than current's key
				else if (key.compareTo(current.getData()) > 0) {
					current = current.getRight();
				}

				if (key.compareTo(current.getData()) == 0) {
					result = prev;
				}
				current.updateHeight();
			}
		}

		return result;
	}

	public void pt_rotateRight(TreeNode<T> anc, TreeNode<T> orig_parent, TreeNode<T> bad_node) {
		if (orig_parent.getData().equals(anc.getRight().getData())) {
			anc.setRight(bad_node);
		}

		else if (orig_parent.getData().equals(anc.getLeft().getData())) {
			anc.setLeft(bad_node);
		}

		orig_parent.setLeft(null);
	
		
		
		
		
		bad_node.setRight(orig_parent);
		
		
		
		
		
		bad_node.updateHeight();
		
		
		
		
		
		
		if (anc != null) {
			anc.updateHeight();
		}
		

		TreeNode<T> extended_ancestor = pt_retrieveParent(anc.getData());
		
		
		
		
		
		
		
		while (extended_ancestor != null) {
			extended_ancestor.updateHeight();
			extended_ancestor = pt_retrieveParent(anc.getData());
		}
	
	
	
	
	}

	
	
	
	
	
	public void pt_rotateLeft(TreeNode<T> ancestor, TreeNode<T> orig_parent, TreeNode<T> bad_node) {
		
		
		
		
		
		if (orig_parent.getData().equals(ancestor.getRight().getData())) {
			ancestor.setRight(bad_node);
		}

		
		
		
		else if (orig_parent.getData().equals(ancestor.getLeft().getData())) {
			ancestor.setLeft(bad_node);
		}

		
		orig_parent.setRight(null);
		
		
		bad_node.setLeft(orig_parent);
		
		
		
		bad_node.updateHeight();
		
		if (ancestor != null) {
			ancestor.updateHeight();
		}
		

		TreeNode<T> extended_ancestor = pt_retrieveParent(ancestor.getData());
		while (extended_ancestor != null) {
			extended_ancestor.updateHeight();
			extended_ancestor = pt_retrieveParent(ancestor.getData());
		}

	}

	
	
	public void insert(final T dat) {
		// parent count must be equal to or higher than the count of children
		// otherwise rotations must be applied

		// use pt_IsValid to scan for invalid nodes and return the first it finds until
		// it has found them all
		// each time pt_IsValid returns an invalid node, call the rotation function
		super.insert(dat);
		TreeNode<T> invalid_node = null;
		invalid_node = pt_isValid(root);
		while (invalid_node != null) {

			TreeNode<T> bad_parent = pt_retrieveParent(invalid_node.getData());
			TreeNode<T> bad_ancestor = pt_retrieveParent(bad_parent.getData());
			if (invalid_node.getData().equals(bad_parent.getRight().getData())) {
				pt_rotateLeft(bad_ancestor, bad_parent, invalid_node);
			}

			if (invalid_node.getData().equals(bad_parent.getLeft().getData())) {
				pt_rotateRight(bad_ancestor, bad_parent, invalid_node);
			}

			invalid_node = pt_isValid(root);
		}

	}


	public TreeNode<T> pt_isValid(TreeNode <T> root) {
		TreeNode<T> off_node = null;
		TreeNode <T> left = null;
		TreeNode <T> right = null;
		TreeNode<T> parent = root;
		
		if (parent != null) {
				left = root.getLeft();
				right = root.getLeft();
			
	
			if (left != null) {
				if (left.getCount() > parent.getCount()) {
					off_node = left;
	
				}
			}
	
			if (right != null) {
				if (right.getCount() > parent.getCount()) {
					off_node = right;
	
				}
			}
	
			if (parent.getHeight() > 1) {
				if (left != null) {
					return pt_isValid(left);
				}
	
				if (right != null) {
					return pt_isValid(right);
				}
			}
		}

		return off_node;
	}

}
