package cp213;

import java.util.ArrayList;

/**
 * Implements a Binary Search Tree.
 *
 * - author your name here -
 *
 * @version 2018-07-12
 *
 * @param <T> The data to store in the tree.
 */
public class BST<T extends Comparable<T>> {

	private int comparisons = 0;
	// Attributes.
	protected TreeNode<T> root = null;
	protected int size = 0;

	/**
	 * Determines if this BST contains key.
	 *
	 * @param key The key to search for.
	 * @return true if this BST contains key, false otherwise.
	 */
	public boolean contains(final T key) {
		boolean contains = false;
		TreeNode<T> current = root;

		if (root != null) {
			while ((current != null) && (contains == false)) {
				if (key.compareTo(current.getData()) < 0) {
					if (current.getLeft() != null) {
						current = current.getLeft();
					}
				} else if (key.compareTo(current.getData()) > 0) {
					if (current.getRight() != null) {
						current = current.getRight();
					}
				}

				else {
					contains = true;
				}
			}
		}
		return contains;
	}

	/**
	 * Determines whether two BSTs are identical.
	 *
	 * @param that The BST to compare this BST against.
	 * @return true if this BST and that BST contain nodes that match in position,
	 *         value, count, and height, false otherwise.
	 */

	public boolean equals(final BST<T> that) {
		boolean equals = true;
		TreeNode<T> current = root;
		TreeNode<T> thatcur = that.root;
		traverseequals(current, thatcur, equals);
		return (equals);
	}

	public boolean traverseequals(final TreeNode<T> current, final TreeNode<T> thatcur, boolean equals) {
		if (current == null && thatcur == null) {
			return equals;
		} else if (current != thatcur) {
			equals = false;
			return (equals);
		}

		else {
			return ((traverseequals(current.getLeft(), thatcur.getLeft(), equals)
					&& (traverseequals(current.getRight(), thatcur.getRight(), equals))));

		}
	}

	/**
	 * 
	 * Get number of comparisons executed by the {@code retrieve} method.
	 *
	 * @return comparisons
	 */
	public int getComparisons() {
		return this.comparisons;
	}

	/**
	 * Returns the height of the root node of this BST.
	 *
	 * @return height of root node, 0 if the root node is null.
	 */
	public int getHeight() {
		int result = 0;
		if (root != null) {
			result = root.getHeight();
		}
		return (result);
	}

	/**
	 * Returns the number of nodes in the BST.
	 *
	 * @return size of this BST.
	 */
	public int getSize() {
		return (this.size);
	}

	/**
	 * Inserts data into this BST.
	 *
	 * @param data Data to store.
	 */
	public void insert(final T key) {
		root = addRecursive(root, key);
	}

	public TreeNode<T> addRecursive(TreeNode<T> current, T value) {
		if (current == null) {
			return new TreeNode<T>(value);
		}

		if (value.compareTo(current.getData()) < 0) {
			current.setLeft(addRecursive(current.getLeft(), value));
		} else if (value.compareTo(current.getData()) > 0) {
			current.setRight(addRecursive(current.getRight(), value));
		} else {
			current.incrementCount();
			size += 1;
			current.updateHeight();
			return current;
		}

		return current;
	}

	/**
	 * Determines if this BST is empty.
	 *
	 * @return true if this BST is empty, false otherwise.
	 */
	public boolean isEmpty() {
		boolean indicator = false;
		if (this.size == 0) {
			indicator = true;
		}
		return (indicator);
	}

	/**
	 * Determines if this BST is a valid BST; i.e. a node's left child data is
	 * smaller than its data, and its right child data is greater than its data. The
	 * height of a node is equal to the maximum of the heights of its two children
	 * (missing child nodes have a height of 0), plus 1.
	 *
	 * @return true if this BST is a valid BST, false otherwise.
	 */
	
	
	public boolean isValid() {
		TreeNode<T> current = root;
		boolean valid = true;
		if (current != null) {
			valid = traverseisvalid(valid, current);
		}
		return (valid);
	}

	
	public boolean traverseisvalid(boolean valid, TreeNode<T> current) {
		if (current == null) {
			valid = true;
		} 
		else if (current != null) {
			if ((current.getLeft() == null) && (current.getRight() == null)&&(current.getHeight() == 1)) {
				valid = true;
			} 
			else if ((current.getData()).compareTo(current.getLeft().getData()) < 0) {
				valid = false;
			} 
			else if ((current.getData().compareTo(current.getRight().getData()))> 0) {
				valid = false;} 
			else {
				valid = traverseisvalid(valid, current.getLeft()) && traverseisvalid(valid, current.getLeft());
			}
		}
		return(valid); 
	}

	
	/**
	 * Resets the comparison count to 0.
	 */
	
	
	public void resetComparisons() {
		this.comparisons = 0;
		return;
	}

	
	
	/**
	 * Retrieves the node whose data matches key. Returning a TreeNode gives access
	 * to the node data and count.
	 *
	 * @param key The key to look for.
	 * @return A DataCountPair object that contains the data that matches key and
	 *         its count, null otherwise.
	 */
	
	
	public TreeNode<T> retrieve(final T key) {
		TreeNode<T> result = null;
		TreeNode<T> current = root;
		while (result == null) {
			if (current.getData() == key) {
				result = current;
			} else if (current.getData().compareTo(key) > 0) {
				comparisons += 1;
				current = current.getLeft();
			} else {
				current = current.getRight();
			}
		}
		return (current);
	}

	
	
	/**
	 * Returns an array of tree nodes from a linked data structure. Not thread safe
	 * as it assumes contents of data structure are not changed by an external
	 * thread during the copy loop. If data elements are added or removed by an
	 * external thread while the data is being copied to the array, then the
	 * declared array size may no longer be valid. The array contents are in data
	 * order.
	 *
	 * @return the tree nodes of a bst as an array of nodes.
	 */
	
	
	
	@SuppressWarnings("unchecked")
	public final TreeNode<T>[] toArray() {
		final ArrayList<TreeNode<T>> queue = new ArrayList<>();
		this.toArrayAux(this.root, queue);
		return queue.toArray(new TreeNode[queue.size()]);
	}

	
	
	/**
	 * Performs an inorder traversal of a tree copying nodes to a queue.
	 *
	 * @param node  a TreeNode
	 * @param queue temporary structure to hold nodes
	 */
	
	
	
	private final void toArrayAux(final TreeNode<T> node, final ArrayList<TreeNode<T>> queue) {
		if (node != null) {
			this.toArrayAux(node.getLeft(), queue);
			queue.add(node);
			this.toArrayAux(node.getRight(), queue);
		}
	}

	
	
	
	/**
	 * Returns the height of a given TreeNode.
	 *
	 * @param node The TreeNode to determine the height of.
	 * @return The value of the height attribute of node, 0 if node is null.
	
	 *
	 *
	 *
	 */
	
	
	
	protected int nodeHeight(final TreeNode<T> node) {
		int result = 0;
		if (node == null) {
			result = 0;
		} else {
			result = node.getHeight();
		}
		return (result);
	}

}







