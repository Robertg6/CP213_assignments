package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import cp213.A05Listeners.*;

public class KeypadView extends JPanel {

	public A05Buttons num_1 = new A05Buttons("1");
	public A05Buttons num_2 = new A05Buttons("2");
	public A05Buttons num_3 = new A05Buttons("3");
	public A05Buttons num_4 = new A05Buttons("4");
	public A05Buttons num_5 = new A05Buttons("5");
	public A05Buttons num_6 = new A05Buttons("6");
	public A05Buttons num_7 = new A05Buttons("7");
	public A05Buttons num_8 = new A05Buttons("8");
	public A05Buttons num_9 = new A05Buttons("9");
	public A05Buttons num_0 = new A05Buttons("0");
	public A05Buttons cash = new A05Buttons("cash");
	public A05Buttons credit = new A05Buttons("credit");
	public A05Buttons A = new A05Buttons("A");
	public A05Buttons B = new A05Buttons("B");
	public A05Buttons C = new A05Buttons("C");
	public A05Buttons D = new A05Buttons("D");
	public static A05Labels screen = new A05Labels(" ");
	public A05Labels blank = new A05Labels(" ");
	public A05Labels blank1 = new A05Labels(" ");
	public A05Labels blank2 = new A05Labels(" ");
	public A05Labels blank3 = new A05Labels(" ");
	public A05Labels blank4 = new A05Labels(" ");
	public A05Labels blank5 = new A05Labels(" ");
	public A05Buttons nickel = new A05Buttons(".05");
	public A05Buttons dime = new A05Buttons(".10");
	public A05Buttons quarter = new A05Buttons(".25");
	public A05Buttons loonie = new A05Buttons("1.00");
	public A05Buttons toonie = new A05Buttons("2.00");
	public A05Buttons five = new A05Buttons("5.00");
	public A05Buttons ten = new A05Buttons("10.00");

	

	private class SameListener implements PropertyChangeListener {

		@Override
		public void propertyChange(final PropertyChangeEvent evt) {

		}
	}

	public KeypadView(String name) {

		this.num_1.setBackground(Color.BLUE);
		this.setLayout(new GridLayout(5, 4));
		this.add(cash);
		this.cash.setBackground(Color.GREEN);
		this.add(credit);
		this.credit.setBackground(Color.GREEN);
		this.add(nickel);
		this.nickel.setBackground(Color.LIGHT_GRAY);
		this.add(dime);
		this.dime.setBackground(Color.LIGHT_GRAY);
		this.add(quarter);
		this.quarter.setBackground(Color.LIGHT_GRAY);
		this.add(loonie);
		this.loonie.setBackground(Color.LIGHT_GRAY);
		this.add(toonie);
		this.toonie.setBackground(Color.LIGHT_GRAY);
		this.add(five);
		this.five.setBackground(Color.LIGHT_GRAY);
		this.add(ten);
		this.ten.setBackground(Color.LIGHT_GRAY);
		this.add(blank);
		this.add(screen);
		
		registerlisteners(nickel);
		registerlisteners(dime);
		registerlisteners(quarter);
		registerlisteners(loonie);
		registerlisteners(toonie);
		registerlisteners(five);
		registerlisteners(ten);
		registerlisteners(cash);
		registerlisteners(credit);
	
		
		
		

	}

	public void registerlisteners(A05Buttons current) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				screen.setText(current.getText());
			}
		});

	}
}