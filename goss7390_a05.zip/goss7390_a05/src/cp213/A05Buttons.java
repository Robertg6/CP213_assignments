package cp213;

import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.*;
//If you need any buttons in your program then they must be the instances of this class.
//You can customize this class as per your need.
public class A05Buttons extends JButton {
	
	public A05Buttons(String name) { 
		super(name);
	}
	
	
}
