package cp213;

public class food_item {

	public String code = "";
	public int stock = 0;
	public double price = 0.0;
	public String name = "";
	
	
	public food_item(String code, int stock, double price) {
		this.name = name;
		this.code = code;
		this.stock = stock;
		this.price = price;
	}

	public void setstock(int num) {
		this.stock = num;		
	}
	public void decrementstock() {
		this.stock = this.stock - 1;
	}
	public String getcode() {
		return(this.code);
	}
	public double getprice() {
		return(this.price);
	}
	public String getname() {
		return(this.name);
	}
}
