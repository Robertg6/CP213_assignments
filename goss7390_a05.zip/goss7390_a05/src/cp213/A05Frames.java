package cp213;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class A05Frames extends JPanel {
	public static food_item A1 = new food_item("A1",10,2.00);
	public static food_item A2 = new food_item("A2",10,2.50);
	public static food_item A3 = new food_item("A3",10,3.00);
	public static food_item A4 = new food_item("A4",10,4.00);
	public static food_item B1 = new food_item("B1",10,3.20);
	public static food_item B2 = new food_item("B2",10,2.55);
	public static food_item B3 = new food_item("B3",10,3.50);
	public static food_item B4 = new food_item("B4",10,2.10);
	public static food_item C1 = new food_item("C1",10,2.15);
	public static food_item C2 = new food_item("C2",10,2.75);
	public static food_item C3 = new food_item("C3",10,3.25);
	public static food_item C4 = new food_item("C4",10,5.00);
	public static food_item D1 = new food_item("D1",10,2.35);
	public static food_item D2 = new food_item("D2",10,2.20);
	public static food_item D3 = new food_item("D3",10,3.30);
	public static food_item D4 = new food_item("D4",10,4.50);
	public static final food_item[] codes = { A1, A2, A3, A4, B1, B2, B3, B4, C1, C2, C3, C4, D1,
			D2, D3, D4 }; 
	public static boolean tellme = false;
	public static food_item selection = null;
	
	
	public ProductView pv = new ProductView("New");
	public KeypadView kv = new KeypadView("New");
	public LegendView lv = new LegendView();
	
	
	public A05Frames() {
		this.setLayout(new GridLayout(2,1,2,2));
		this.pv = new ProductView("New");
		this.add(this.pv);
		this.add(this.kv);
		this.add(this.lv);
		this.layoutView();
		registerlisteners(pv.A1);
		registerlisteners(pv.A2);
		registerlisteners(pv.A3);
		registerlisteners(pv.A4);
		registerlisteners(pv.B1);
		registerlisteners(pv.B2);
		registerlisteners(pv.B3);
		registerlisteners(pv.B4);
		registerlisteners(pv.C1);
		registerlisteners(pv.C2);
		registerlisteners(pv.C3);
		registerlisteners(pv.C4);
		registerlisteners(pv.D1);
		registerlisteners(pv.D2);
		registerlisteners(pv.D3);
		registerlisteners(pv.D4);
		cashlistener(kv.cash);
		traylisteners(pv.A1);
		traylisteners(pv.A2);
		traylisteners(pv.A3);
		traylisteners(pv.A4);
		traylisteners(pv.B1);
		traylisteners(pv.B2);
		traylisteners(pv.B3);
		traylisteners(pv.B4);
		traylisteners(pv.C1);
		traylisteners(pv.C2);
		traylisteners(pv.C3);
		traylisteners(pv.C4);
		traylisteners(pv.D1);
		traylisteners(pv.D2);
		traylisteners(pv.D3);
		traylisteners(pv.D4);
	}
	
	
	
	
	private void layoutView() {
		// Place the numeric and button views on top and the graphic view
		// underneath.
		
		this.setLayout(new BorderLayout());
		this.add(this.pv, BorderLayout.WEST);
		this.add(this.kv, BorderLayout.EAST);
		this.add(this.lv, BorderLayout.CENTER);
		this.setVisible(true);
		
	
		
		
	

}
	
	public void registerlisteners(A05Buttons current) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean indic = true;
				if(indic = true) {
				String name = current.getText();
				boolean valid = false;
				int i = 0;
				double price = 0;
				while((valid == false) && (i < A05Frames.codes.length)) {
					if(name.equals(codes[i].getcode())==true) {
						valid = true;
						price = codes[i].getprice();
						selection = codes[i];
						
							
					}
					else {
					i++;
				}}
				
				String s = Double.toString(price);
				if(tellme == true) {
				KeypadView.screen.setText("Price: " + s);
			indic = false;}
				else{
				 {
						if(tellme == true) {
						ProductView.tray.setText("Heres your: " + current.getText());
					}}
					
				}}}}
		);

	}

	public void cashlistener(A05Buttons current) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				KeypadView.screen.setText(current.getText());
				if(current.getText().equals("cash")) {
					
				}
			}
		});

}
	public void traylisteners(A05Buttons current) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				
				ProductView.tray.setText( current.getText());
			}
		});

	}



}
