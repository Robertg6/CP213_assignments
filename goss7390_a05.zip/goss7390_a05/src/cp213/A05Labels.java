package cp213;

import javax.swing.JLabel;

public class A05Labels extends JLabel {
	public A05Labels(String name) { 
		super(name);
	}
}
