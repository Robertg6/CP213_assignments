package cp213;

import javax.swing.JFrame;
import javax.swing.JButton;


//This is the main class to initiate the program.
//It is recommended that you have implemented main()only in this class, unless otherwise required.
public class A05 {

	public static void main(String[] args) {

		JFrame vending = new JFrame("Vend-o-matic");
		A05Frames fr = new A05Frames();
		vending.add(fr);
		vending.setVisible(true);
		
		
		
	}

}