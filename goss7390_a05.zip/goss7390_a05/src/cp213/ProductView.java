package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class ProductView extends JPanel{
	
	public A05Buttons A1 = new A05Buttons("A1");
	public A05Buttons A2 = new A05Buttons("A2" );
	public A05Buttons A3 = new A05Buttons("A3");
	public A05Buttons A4 = new A05Buttons("A4");
	public A05Buttons B1 = new A05Buttons("B1");
	public A05Buttons B2 = new A05Buttons("B2");
	public A05Buttons B3 = new A05Buttons("B3");
	public A05Buttons B4 = new A05Buttons("B4");
	public A05Buttons C1 = new A05Buttons("C1");
	public A05Buttons C2 = new A05Buttons("C2");
	public A05Buttons C3 = new A05Buttons("C3");
	public A05Buttons C4 = new A05Buttons("C4");
	public A05Buttons D1 = new A05Buttons("D1");
	public A05Buttons D2 = new A05Buttons("D2");
	public A05Buttons D3 = new A05Buttons("D3");
	public A05Buttons D4 = new A05Buttons("D4");
	public static A05Labels tray = new A05Labels("out");
	public ProductView(String name) {
	
	this.setLayout(new GridLayout(5,5));
	this.add(A1);
	this.A1.setBackground(Color.RED);
	this.add(A2);
	this.A2.setBackground(Color.RED);
	this.add(A3);
	this.A3.setBackground(Color.RED);
	this.add(A4);
	this.A4.setBackground(Color.RED);
	this.add(B1);
	this.B1.setBackground(Color.RED);
	this.add(B2);
	this.B2.setBackground(Color.RED);
	this.add(B3);
	this.B3.setBackground(Color.BLUE);
	this.add(B4);
	this.B4.setBackground(Color.BLUE);
	this.add(C1);
	this.C1.setBackground(Color.BLUE);
	this.add(C2);
	this.C2.setBackground(Color.BLUE);
	this.add(C3);
	this.C3.setBackground(Color.YELLOW);
	this.add(C4);
	this.C4.setBackground(Color.YELLOW);
	this.add(D1);
	this.D1.setBackground(Color.YELLOW);
	this.add(D2);
	this.D2.setBackground(Color.YELLOW);
	this.add(D3);
	this.D3.setBackground(Color.YELLOW);
	this.add(D4);
	this.D4.setBackground(Color.GREEN);
	this.add(tray);
	
}
	
	public void traylisteners(A05Buttons current) {
		current.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				tray.setText("Heres your: " + current.getText());
			}
		});

	}


}
