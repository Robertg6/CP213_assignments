package cp213;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.DecimalFormat;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


//If you need to implement/use a listener in your program then it must be an instance of this class.
//You can add suitable Interfaces to the header/definition of this class using implements.

import java.util.Random;


public class A05Listeners {

	private String componentID;//your own unique way of identifying components that will be attached
	//to the A05Listener objects. This way you will be able to distinguish that which component has
	//invoked the action handler.
	
	public A05Listeners(String arg) {//DO NOT modify this line
		componentID = arg;//DO NOT modify this line
	
		
		
		class KeypadListener implements ActionListener{
			A05Buttons current = new A05Buttons("");
 			KeypadView view = new KeypadView("");
 			
			
 			public KeypadListener(A05Buttons current, KeypadView view) {
				this.current = current;
				this.view = view;
				
	
			}
			@Override
			public void actionPerformed(final ActionEvent evt) {
				this.view.screen.setText(this.current.getText());
				}
			} 
		
	
	}
	
	

	private double change = 0.0;
	public static final String[] codes = { "A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1",
			"D2", "D3", "D4" };
	public int num_nickels = 20;
	public int num_dimes = 10;
	public int num_quaters = 12;
	public int num_loonies = 0;
	public int num_toonies = 0;
	public int num_fives = 0;
	public int num_tens = 0;

	public food_item A1 = new food_item("A1",10,2.00);
	public food_item A2 = new food_item("A2",10,2.50);
	public food_item A3 = new food_item("A3",10,3.00);
	public food_item A4 = new food_item("A4",10,4.00);
	public food_item B1 = new food_item("B1",10,3.20);
	public food_item B2 = new food_item("B2",10,2.55);
	public food_item B3 = new food_item("B3",10,3.50);
	public food_item B4 = new food_item("B4",10,2.10);
	public food_item C1 = new food_item("C1",10,2.15);
	public food_item C2 = new food_item("C2",10,2.75);
	public food_item C3 = new food_item("C3",10,3.25);
	public food_item C4 = new food_item("C4",10,5.00);
	public food_item D1 = new food_item("D1",10,2.35);
	public food_item D2 = new food_item("D2",10,2.20);
	public food_item D3 = new food_item("D3",10,3.30);
	public food_item D4 = new food_item("D4",10,4.50);
	
	public void get_change_amount(double cash, food_item selection) {
		this.change = cash - selection.getprice();
	}

	public boolean sufficient_funds(double cash, food_item selection) {
		boolean valid = true;
		if (cash < selection.getprice()) {
			valid = false;
		}
		if(selection.stock == 0) {
			valid = false;
		}
		return (valid);
	}

	public boolean sufficient_change(double cash) {
		boolean valid = true;
		double amount = cash;
		int nickels = num_nickels;
		int dimes = num_dimes;
		int quarters = num_quaters;
		int loonies = num_loonies;
		int toonies = num_toonies;
		int fives = num_fives;
		int tens  = num_tens;
		int quaters = num_quaters;
		
		
		while ((amount > 0) && (valid == true)) {
			if ((tens > 0) && (amount >= 10)) {
				tens = tens - 1;
				amount = amount - 10;

			} else if ((fives > 0) && (amount >= 5)) {
				fives = fives - 1;
				amount = amount - 5;

			} else if ((toonies > 0) && (amount >= 2)) {
				toonies = toonies - 1;
				amount = amount - 2;

			} else if ((loonies > 0) && (amount >= 1)) {
				loonies = loonies - 1;
				amount = amount - 1;

			} else if ((quaters > 0) && (amount >= .25)) {
				quaters = quaters - 1;
				amount = amount - .25;

			} else if ((dimes > 0) && (amount > .1)) {
				dimes = dimes - 1;
				amount = amount - .1;

			} else if ((nickels > 0) && (amount > .5)) {
				nickels = nickels - 1;
				amount = amount - .05;

			} else {
				valid = false;
			}
		}
		return (valid);
	}
	public double make_change(double cash, food_item selection) {
		
		double change = cash;
		while ((cash > 0)) {
			if ((num_tens > 0) && (cash >= 10)) {
				num_tens = num_tens - 1;
				cash = cash - 10;

			} else if ((num_fives > 0) && (cash >= 5)) {
				num_fives = num_fives - 1;
				cash = cash - 5;

			} else if ((num_toonies > 0) && (cash >= 2)) {
				num_toonies = num_toonies - 1;
				cash = cash - 2;

			} else if ((num_loonies > 0) && (cash >= 1)) {
				num_loonies = num_loonies - 1;
				cash = cash - 1;

			} else if ((num_quaters > 0) && (cash >= .25)) {
				num_quaters = num_quaters - 1;
				cash = cash - .25;

			} else if ((num_dimes > 0) && (cash > .1)) {
				num_dimes = num_dimes - 1;
				cash = cash - .1;

			} else if ((num_nickels > 0) && (cash > .5)) {
				num_nickels = num_nickels - 1;
				cash = cash - .05;

			} 
		}
		selection.stock -= 1;
		return (change);
	}
	
	public boolean credit_payment(food_item selection) {
		boolean valid = true;
		if(selection.stock == 0) {
			valid = false;
		}
		Random rn = new Random();
		int random_num = rn.nextInt((10-1)+1)+1;
		if((valid == true) && random_num == 2) {
			valid = false;
		}
		if(valid == true) {
		selection.stock -= 1;}
		return(valid);
	}

 
}


