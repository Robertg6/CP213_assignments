package cp213;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import cp213.A05Listeners.*;

public class LegendView extends JPanel {
	
	public A05Labels Chocolate = new A05Labels("Chocolate = Blue");
	public A05Labels Chips = new A05Labels("Chips = Red" );
	public A05Labels Gum = new A05Labels("Gum = Yellow");
	public A05Labels Other = new A05Labels("Other = Green");
	public A05Labels green = new A05Labels(" ");
	public A05Labels yellow = new A05Labels(" ");
	public A05Labels blue = new A05Labels(" ");
	public A05Labels red = new A05Labels(" ");
	
	public LegendView() {
		this.Chocolate = Chocolate;
		this.Chips = Chips;
		this.Gum = Gum;
		this.Other = Other;
		this.green = green;
		this.blue = blue;
		this.yellow = yellow;
		this.red = red;
		
		this.setLayout(new GridLayout(5,5));
		this.add(Chips);
		this.add(Chocolate);
		this.add(Gum);
		this.add(Other);
	}
	
}
