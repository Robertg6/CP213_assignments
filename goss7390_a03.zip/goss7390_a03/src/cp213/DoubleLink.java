package cp213;

/**
 * The class for doubly-linked data structures. Provides attributes
 * and implementations for getLength, isEmpty, and toArray methods.
 * The head attribute is the first node in any doubly-linked list and
 * last is the last node.
 *
 * @author Robert Goss
 * @version 2019-10-08
 * 
 */
public class DoubleLink {

    // First node of double linked list
    private DoubleNode head = null;

    // Number of elements currently stored in linked list
    private int length = 0;

    // Last node of double linked list.
    private DoubleNode last = null;

    /**
     * Adds a new Movie element to the list at the head position
     * before the previous head, if any. Increments the length of the List.
	 *
     * @param value
     *            The value to be added at the head of the list.
	 *
     * @return true if node is added successfully, else false.
     */
    public final boolean addNode(final Movie value) {
    	DoubleNode newthing = new DoubleNode(value, null, head);
    	boolean indication = false;
    	if (head != null) {
    		head.setPrev(newthing);
    		
    	}
    	head = newthing;
    	if (last == null) {
    		last = newthing;
    	}
    	length++;
    	indication = true;
    	
    	
    	
	return indication;//you must change this statement as per your requirement
    }

    /**
     * Returns the head element in the linked structure. Must be copy safe.
     *
     * @return the head node.
     */
    public Movie removeFront() {
    	Movie value = this.head.getValue();
    	
    	DoubleNode newhead = this.head.getNext();
    	
    	if (newhead == null && length == 1) {
    		this.head = null;
    		this.last = null;
    		this.length = 0;
    	}else {
    		this.head = newhead;
    		this.length--;}
    	return value;}
    	
    	
    public final DoubleNode getHead() {
    	 DoubleNode newhead = new DoubleNode(head.getValue(), null, head.getNext());
	return(newhead);//you must change this statement as per your requirement
    }

    /**
     * Returns the current number of elements in the linked structure.
     *
     * @return the value of length.
     */
    public final int getLength() {
    	int result = length;
	return(result);//you must change this statement as per your requirement
    }

    /**
     * Returns the last node in the linked structure. Must be copy safe.
     *
     * @return the last node.
     */
    public final DoubleNode getLast() {
    	DoubleNode result = new DoubleNode(last.getValue(), last.getPrev(), last.getNext());
	return(result);//you must change this statement as per your requirement
    }

    /**
     * Determines whether the double linked list is empty or not.
     *
     * @return true if list is empty, false otherwise.
     */
    public final boolean isEmpty() {
    	boolean empty = false;
    	if (length == 0) {
    		empty = true;
    	}
	return(empty);//you must change this statement as per your requirement
    }

    /**
     * Returns all the data in the list in the form of an array.
     *
     * @return The array of Movie elements. Must be copy safe
     */
    public final Movie [] toArray() {
    	Movie[] movielist = new Movie[getLength()];
    	DoubleNode currentNode = getHead();
    	int i = 0;
    	while (i < getLength()) {
    		movielist[i] = currentNode.getValue();
    		if (currentNode != last) {
    			currentNode = currentNode.getNext();
    			}
    		i++;	
    	}
	return(movielist);//you must change this statement as per your requirement
    }
}
